﻿using System;
namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string command = Console.ReadLine();
            List<Tire[]>tires = new List<Tire[]>();
            List<Engine>engines = new List<Engine>();
            while(command!= "No more tires")
            {
                double[] tiresValues = command
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .Select(double.Parse)
                    .ToArray();
                Tire[] newTires = new Tire[4]
                {
                    new Tire((int)tiresValues[0],tiresValues[1]),
                    new Tire((int)tiresValues[2],tiresValues[3]),
                    new Tire((int)tiresValues[4],tiresValues[5]),
                    new Tire((int)tiresValues[6],tiresValues[7]),

                };
                tires.Add(newTires);

                command = Console.ReadLine();
            }
            string nextCommand= Console.ReadLine();
            while(nextCommand!= "Engines done")
            {
                double[]tokens=nextCommand
                .Split(" ",StringSplitOptions.RemoveEmptyEntries)
                .Select(double.Parse)
                .ToArray();
                int horsePower = (int)tokens[0];
                double cubicCapacity = tokens[1];
                Engine newEngine = new Engine(horsePower, cubicCapacity);
                engines.Add(newEngine);
                nextCommand = Console.ReadLine();

            }
            string finalCommand = Console.ReadLine();
            List<Car> cars = new List<Car>();
            //{make} {model} {year} {fuelQuantity} {fuelConsumption} {engineIndex} {tiresIndex}
            while(finalCommand!="Show special")
            {
                string[] parametursForCar = finalCommand
                    .Split()
                    .ToArray();
                string make = parametursForCar[0];
                string model = parametursForCar[1];
                int year = int.Parse(parametursForCar[2]);
                double fuelQuantity = double.Parse(parametursForCar[3]);
                double fuelConsumption = double.Parse(parametursForCar[4]);
                int engineIndex = int.Parse(parametursForCar[5]);
                int tiresIndex=int.Parse(parametursForCar[6]);

                Car currentNewCar= new Car(make, model, year, fuelQuantity, fuelConsumption
                    , engines[engineIndex], tires[tiresIndex]);
                cars.Add(currentNewCar);
                finalCommand=Console.ReadLine();
            }

            foreach(Car car in cars)
            {
               double sumPressure=car.SumTiresPressure();
               if(sumPressure>=9 && sumPressure <= 10)
               {
                    car.Drive(20);
                    Console.WriteLine(car.ShowSpecialCars());
               }
            }
        }
    }
}